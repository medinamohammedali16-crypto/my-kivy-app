import pygame
import sys
import random
import math
import os

# ---- INITIALIZATION ----
pygame.init()
pygame.mixer.init() 
info = pygame.display.Info()
WIDTH, HEIGHT = info.current_w, info.current_h
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("Ludo Elite - Pro Edition")
clock = pygame.time.Clock()

# ---- SOUND SETTINGS ----
sound_on = True  
music_on = True

# ---- SOUND EFFECTS LOAD ----
def load_sounds():
    """
    ድምጾቹን ለመጫን ይሞክራል። ፋይሎቹ ከሌሉ ስህተት እንዳይፈጠር 
    ባዶ (None) ይመልሳል።
    """
    try:
        # እነዚህ ፋይሎች በፎልደሩ ውስጥ መኖራቸውን እርግጠኛ ይሁኑ
        d_snd = pygame.mixer.Sound("dice.wav") 
        k_snd = pygame.mixer.Sound("kill_sound.wav") 
        return d_snd, k_snd
    except Exception as e:
        print(f"ድምጾቹን መጫን አልተቻለም: {e}")
        return None, None

dice_sound, kill_sound = load_sounds()

def play_sound(sound):
    if sound_on and sound:
        sound.play()

# ---- COLORS ----
WHITE, BLACK = (255, 255, 255), (0, 0, 0)
BG = (5, 10, 48)
UI_BLUE = (21, 67, 134)
RED = (236, 28, 36)
GREEN = (34, 177, 76)
BLUE = (63, 72, 204)
YELLOW = (255, 242, 0)

DARK_RED, DARK_GREEN = (150, 0, 0), (0, 100, 0)
DARK_BLUE, DARK_YELLOW = (0, 0, 150), (180, 180, 0)
STAR_GOLD = (218, 165, 32)
TILE_BORDER = (180, 180, 180)

# ---- DYNAMIC SIZING ----
CELL = min(WIDTH, HEIGHT) // 20
BOARD_X = (WIDTH - (CELL * 15)) // 2
BOARD_Y = (HEIGHT - (CELL * 15)) // 2 + 30

font_ui = pygame.font.SysFont("Arial", int(CELL * 1.2), True)
font_btn = pygame.font.SysFont("Arial", int(CELL * 0.7), True)

# ---- GAME DATA ----
tokens = {"RED": [-1]*4, "GREEN": [-1]*4, "YELLOW": [-1]*4, "BLUE": [-1]*4}
current_turn = "RED"
dice_val = 1
rolling = False
waiting_move = False
roll_timer = 0
player_count = 4
current_state = "MENU"
winner = None

animating = False
anim_token_idx = -1
anim_target_pos = -1
anim_step_timer = 0

# Paths
outer_path = [(1,6), (2,6), (3,6), (4,6), (5,6), (6,5), (6,4), (6,3), (6,2), (6,1), (6,0), (7,0), (8,0), (8,1), (8,2), (8,3), (8,4), (8,5), (9,6), (10,6), (11,6), (12,6), (13,6), (14,6), (14,7), (14,8), (13,8), (12,8), (11,8), (10,8), (9,8), (8,9), (8,10), (8,11), (8,12), (8,13), (8,14), (7,14), (6,14), (6,13), (6,12), (6,11), (6,10), (6,9), (5,8), (4,8), (3,8), (2,8), (1,8), (0,8), (0,7), (0,6)]
HOME_PATHS = {"RED": [(1,7), (2,7), (3,7), (4,7), (5,7), (6,7)], "GREEN": [(7,1), (7,2), (7,3), (7,4), (7,5), (7,6)], "YELLOW": [(13,7), (12,7), (11,7), (10,7), (9,7), (8,7)], "BLUE": [(7,13), (7,12), (7,11), (7,10), (7,9), (7,8)]}
START_IDX = {"RED": 0, "GREEN": 13, "YELLOW": 26, "BLUE": 39}
SAFE_POS_GLOBAL = [(2,8), (6,2), (12,6), (8,12)] 

DICE_SIZE = int(CELL * 1.6)
D_OFF = CELL * 2
DICE_POS = {
    "RED": (BOARD_X - D_OFF, BOARD_Y), 
    "GREEN": (BOARD_X + CELL*15 + (D_OFF-DICE_SIZE), BOARD_Y), 
    "BLUE": (BOARD_X - D_OFF, BOARD_Y + CELL*13.4), 
    "YELLOW": (BOARD_X + CELL*15 + (D_OFF-DICE_SIZE), BOARD_Y + CELL*13.4)
}

# ---- UI & DRAWING FUNCTIONS ----
def draw_rounded_rect(surface, rect, color, radius=15):
    pygame.draw.rect(surface, color, rect, border_radius=radius)
    pygame.draw.rect(surface, WHITE, rect, 2, border_radius=radius)

def draw_gear_icon(surface, x, y, size):
    pygame.draw.circle(surface, WHITE, (x, y), size // 2, 2)
    for i in range(8):
        angle = i * (math.pi / 4)
        px = x + (size//2) * math.cos(angle)
        py = y + (size//2) * math.sin(angle)
        pygame.draw.line(surface, WHITE, (x, y), (px, py), 3)
    pygame.draw.circle(surface, BG, (x, y), size // 4)
    return pygame.Rect(x - size//2, y - size//2, size, size)

def draw_star(surface, x, y, size, color):
    points = []
    for i in range(10):
        angle = i * math.pi / 5
        r = size if i % 2 == 0 else size // 2
        points.append((x + r * math.sin(angle), y - r * math.cos(angle)))
    pygame.draw.polygon(surface, color, points)

def draw_arrow(surface, color, x, y, size, direction):
    points = []
    if direction == "right": points = [(x, y - size), (x + size, y), (x, y + size)]
    elif direction == "left": points = [(x, y - size), (x - size, y), (x, y + size)]
    elif direction == "down": points = [(x - size, y), (x, y + size), (x + size, y)]
    elif direction == "up": points = [(x - size, y), (x, y - size), (x + size, y)]
    pygame.draw.polygon(surface, color, points)

def draw_premium_token(surface, x, y, color_name, is_movable):
    base_color = eval(color_name)
    dark_color = eval("DARK_" + color_name)
    radius = int(CELL * 0.38)
    if is_movable:
        glow = int(radius + 4 + math.sin(pygame.time.get_ticks() * 0.01) * 4)
        s = pygame.Surface((glow*2, glow*2), pygame.SRCALPHA)
        pygame.draw.circle(s, (255, 255, 255, 120), (glow, glow), glow)
        surface.blit(s, (x - glow, y - glow))
    pygame.draw.circle(surface, dark_color, (x, y + 2), radius) 
    pygame.draw.circle(surface, base_color, (x, y), radius) 
    pygame.draw.circle(surface, WHITE, (x, y), radius, 2) 

def draw_dice(color, val, is_rolling):
    x, y = DICE_POS[color]
    rect = pygame.Rect(x, y, DICE_SIZE, DICE_SIZE)
    if current_turn == color:
        pygame.draw.rect(screen, WHITE, rect.inflate(10, 10), border_radius=12)
    pygame.draw.rect(screen, WHITE, rect, border_radius=10)
    pygame.draw.rect(screen, BLACK, rect, 2, border_radius=10)
    display_val = random.randint(1, 6) if is_rolling and current_turn == color else val
    dots = {1:[(0.5,0.5)], 2:[(0.2,0.2),(0.8,0.8)], 3:[(0.2,0.2),(0.5,0.5),(0.8,0.8)], 4:[(0.2,0.2),(0.2,0.8),(0.8,0.2),(0.8,0.8)], 5:[(0.2,0.2),(0.2,0.8),(0.5,0.5),(0.8,0.2),(0.8,0.8)], 6:[(0.25,0.2),(0.25,0.5),(0.25,0.8),(0.75,0.2),(0.75,0.5),(0.75,0.8)]}
    for dx, dy in dots[display_val]:
        pygame.draw.circle(screen, BLACK, (int(x + dx*DICE_SIZE), int(y + dy*DICE_SIZE)), int(DICE_SIZE*0.1))
    return rect

def draw_board():
    screen.fill(BG)
    pygame.draw.rect(screen, STAR_GOLD, (BOARD_X-10, BOARD_Y-10, CELL*15+20, CELL*15+20), 10, border_radius=5)
    
    for tx in range(15):
        for ty in range(15):
            rect = (BOARD_X + tx*CELL, BOARD_Y + ty*CELL, CELL, CELL)
            is_path = False
            if ty == 7 and 1 <= tx <= 5: pygame.draw.rect(screen, RED, rect); is_path = True
            elif tx == 7 and 1 <= ty <= 5: pygame.draw.rect(screen, GREEN, rect); is_path = True
            elif ty == 7 and 9 <= tx <= 13: pygame.draw.rect(screen, YELLOW, rect); is_path = True
            elif tx == 7 and 9 <= ty <= 13: pygame.draw.rect(screen, BLUE, rect); is_path = True
            elif (tx, ty) in outer_path:
                pygame.draw.rect(screen, WHITE, rect)
                is_path = True
            
            start_tiles = {"RED":(1,6), "GREEN":(8,1), "YELLOW":(13,8), "BLUE":(6,13)}
            for color_name, pos in start_tiles.items():
                if (tx, ty) == pos:
                    pygame.draw.rect(screen, eval(color_name), rect)
                    is_path = True

            if is_path:
                pygame.draw.rect(screen, BLACK, rect, 1)

    for tx, ty in SAFE_POS_GLOBAL:
        draw_star(screen, BOARD_X + tx*CELL + CELL//2, BOARD_Y + ty*CELL + CELL//2, CELL//3, STAR_GOLD)

    draw_arrow(screen, RED, BOARD_X + 1.5*CELL, BOARD_Y + 6.5*CELL, CELL//3, "down")
    draw_arrow(screen, GREEN, BOARD_X + 8.5*CELL, BOARD_Y + 1.5*CELL, CELL//3, "left")
    draw_arrow(screen, YELLOW, BOARD_X + 13.5*CELL, BOARD_Y + 8.5*CELL, CELL//3, "up")
    draw_arrow(screen, BLUE, BOARD_X + 6.5*CELL, BOARD_Y + 13.5*CELL, CELL//3, "right")

    bases = [(0, 0, RED, "RED"), (9, 0, GREEN, "GREEN"), (9, 9, YELLOW, "YELLOW"), (0, 9, BLUE, "BLUE")]
    for bx, by, color, color_name in bases:
        pygame.draw.rect(screen, color, (BOARD_X+bx*CELL, BOARD_Y+by*CELL, CELL*6, CELL*6))
        pygame.draw.rect(screen, WHITE, (BOARD_X+(bx+1)*CELL, BOARD_Y+(by+1)*CELL, CELL*4, CELL*4), border_radius=10)
        offs = [(1.8, 1.8), (4.2, 1.8), (1.8, 4.2), (4.2, 4.2)]
        for i in range(4):
            sx, sy = int(BOARD_X + (bx+offs[i][0])*CELL), int(BOARD_Y + (by+offs[i][1])*CELL)
            slot_color = color if tokens[color_name][i] == -1 else (200,200,200)
            pygame.draw.circle(screen, slot_color, (sx, sy), int(CELL * 0.45))
            pygame.draw.circle(screen, BLACK, (sx, sy), int(CELL * 0.45), 2)

    cx, cy = BOARD_X + 7.5*CELL, BOARD_Y + 7.5*CELL
    pts = [(RED, [(cx, cy), (BOARD_X+6*CELL, BOARD_Y+6*CELL), (BOARD_X+6*CELL, BOARD_Y+9*CELL)]), (GREEN, [(cx, cy), (BOARD_X+6*CELL, BOARD_Y+6*CELL), (BOARD_X+9*CELL, BOARD_Y+6*CELL)]), (YELLOW, [(cx, cy), (BOARD_X+9*CELL, BOARD_Y+6*CELL), (BOARD_X+9*CELL, BOARD_Y+9*CELL)]), (BLUE, [(cx, cy), (BOARD_X+6*CELL, BOARD_Y+9*CELL), (BOARD_X+9*CELL, BOARD_Y+9*CELL)])]
    for clr, p in pts:
        pygame.draw.polygon(screen, clr, p); pygame.draw.polygon(screen, WHITE, p, 2)

# ---- LOGIC FUNCTIONS ----
def get_pixel(color, pos, idx):
    if pos == -1:
        bx, by = (0,0) if color=="RED" else (9,0) if color=="GREEN" else (9,9) if color=="YELLOW" else (0,9)
        offs = [(1.8, 1.8), (4.2, 1.8), (1.8, 4.2), (4.2, 4.2)]
        return int(BOARD_X + (bx+offs[idx][0])*CELL), int(BOARD_Y + (by+offs[idx][1])*CELL)
    if pos < 51: gx, gy = outer_path[(pos + START_IDX[color]) % 52]
    else: gx, gy = HOME_PATHS[color][min(pos - 51, 5)]
    return int(BOARD_X + gx*CELL + CELL//2), int(BOARD_Y + gy*CELL + CELL//2)

def check_killing(color, pos):
    if pos >= 51: return False
    actual_pos_coords = outer_path[(pos + START_IDX[color]) % 52]
    safe_zones = SAFE_POS_GLOBAL + [(1,6), (8,1), (13,8), (6,13)]
    if actual_pos_coords in safe_zones: return False 
    killed = False  
    for c, tks in tokens.items():  
        if c == color: continue  
        for i, p in enumerate(tks):  
            if p != -1 and p < 51:  
                if outer_path[(p + START_IDX[c]) % 52] == actual_pos_coords:  
                    tokens[c][i] = -1  
                    killed = True
                    play_sound(kill_sound) # የመግደል ድምፅ
    return killed

def next_turn():
    global current_turn, waiting_move
    waiting_move = False
    order = ["RED", "GREEN", "YELLOW", "BLUE"][:player_count]
    current_turn = order[(order.index(current_turn) + 1) % len(order)]

def finish_move(t_idx):
    global current_turn, current_state, winner, dice_val, waiting_move
    killed = check_killing(current_turn, tokens[current_turn][t_idx])
    if all(p == 56 for p in tokens[current_turn]): winner, current_state = current_turn, "WIN"
    if dice_val != 6 and not killed: next_turn()
    else: waiting_move = False

# ---- MAIN LOOP ----
run = True
while run:
    if current_state == "MENU":
        screen.fill(BG)
        title = font_ui.render("LUDO ELITE", True, STAR_GOLD)
        screen.blit(title, (WIDTH//2 - title.get_width()//2, 80))
        gear_rect = draw_gear_icon(screen, WIDTH - 50, 50, 40)
        m_btns = [(pygame.Rect(WIDTH//2-175, 220, 350, 60), "VS COMPUTER", DARK_GREEN), (pygame.Rect(WIDTH//2-175, 300, 350, 60), "LOCAL MULTIPLAYER", DARK_RED), (pygame.Rect(WIDTH//2-175, 380, 350, 60), "PLAY WITH FRIENDS", DARK_BLUE)]
        for r, txt, clr in m_btns:
            draw_rounded_rect(screen, r, clr)
            ts = font_btn.render(txt, True, WHITE)
            screen.blit(ts, (r.centerx - ts.get_width()//2, r.centery - ts.get_height()//2))

        for event in pygame.event.get():
            if event.type == pygame.QUIT: run = False
            if event.type == pygame.MOUSEBUTTONDOWN:
                if gear_rect.collidepoint(event.pos): current_state = "SETTINGS"
                for r, txt, clr in m_btns:
                    if r.collidepoint(event.pos): current_state = "SELECT_PLAYER"

    elif current_state == "SETTINGS":
        screen.fill(BG)
        panel = pygame.Rect(WIDTH//2-150, HEIGHT//2-100, 300, 240)
        draw_rounded_rect(screen, panel, UI_BLUE)
        s_btn = pygame.Rect(WIDTH//2-100, HEIGHT//2-60, 200, 50)
        m_btn = pygame.Rect(WIDTH//2-100, HEIGHT//2+10, 200, 50)
        back_btn = pygame.Rect(WIDTH//2-50, HEIGHT//2+80, 100, 40)
        draw_rounded_rect(screen, s_btn, DARK_GREEN if sound_on else DARK_RED)
        draw_rounded_rect(screen, m_btn, DARK_GREEN if music_on else DARK_RED)
        draw_rounded_rect(screen, back_btn, BLACK)
        screen.blit(font_btn.render(f"Sound: {'ON' if sound_on else 'OFF'}", True, WHITE), (s_btn.centerx-60, s_btn.centery-15))
        screen.blit(font_btn.render(f"Music: {'ON' if music_on else 'OFF'}", True, WHITE), (m_btn.centerx-60, m_btn.centery-15))
        screen.blit(font_btn.render("BACK", True, WHITE), (back_btn.centerx-25, back_btn.centery-12))
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                if s_btn.collidepoint(event.pos): sound_on = not sound_on
                if m_btn.collidepoint(event.pos): music_on = not music_on
                if back_btn.collidepoint(event.pos): current_state = "MENU"

    elif current_state == "SELECT_PLAYER":
        screen.fill(BG)
        btns = []
        for i in range(2, 5):
            r = pygame.Rect(WIDTH//2-120, HEIGHT//2 - 120 + i*70, 240, 60)
            btns.append((r, i))
            draw_rounded_rect(screen, r, DARK_GREEN)
            screen.blit(font_btn.render(f"{i} PLAYERS", True, WHITE), (r.centerx-50, r.centery-15))
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN:
                for r, count in btns:
                    if r.collidepoint(event.pos): player_count, current_state = count, "GAME"

    elif current_state == "GAME":  
        draw_board()  
        dice_rects = {c: draw_dice(c, dice_val, rolling) for c in ["RED", "GREEN", "YELLOW", "BLUE"][:player_count]}
        gear_rect = draw_gear_icon(screen, WIDTH - 50, 50, 30)

        if animating:
            if pygame.time.get_ticks() - anim_step_timer > 150:
                tokens[current_turn][anim_token_idx] += 1
                anim_step_timer = pygame.time.get_ticks()
                if tokens[current_turn][anim_token_idx] >= anim_target_pos:
                    animating = False
                    finish_move(anim_token_idx)

        for color_name, tks in tokens.items():  
            if color_name not in ["RED", "GREEN", "YELLOW", "BLUE"][:player_count]: continue
            for i, p in enumerate(tks):  
                if p == 56: continue 
                tx, ty = get_pixel(color_name, p, i)  
                is_movable = waiting_move and current_turn == color_name and not animating and ((p >= 0 and p + dice_val <= 56) or (p == -1 and dice_val == 6))
                draw_premium_token(screen, tx, ty, color_name, is_movable)

        for event in pygame.event.get():  
            if event.type == pygame.QUIT: run = False  
            if event.type == pygame.MOUSEBUTTONDOWN and not animating:  
                if gear_rect.collidepoint(event.pos): current_state = "SETTINGS"
                elif not rolling and not waiting_move:  
                    if current_turn in dice_rects and dice_rects[current_turn].collidepoint(event.pos):  
                        rolling, roll_timer = True, pygame.time.get_ticks()  
                        play_sound(dice_sound) # የዳይስ ድምፅ
                elif waiting_move:  
                    for i in range(4):  
                        tx, ty = get_pixel(current_turn, tokens[current_turn][i], i)  
                        if pygame.Rect(tx-20, ty-20, 40, 40).collidepoint(event.pos):  
                            if tokens[current_turn][i] == -1 and dice_val == 6: 
                                tokens[current_turn][i] = 0; finish_move(i)
                            elif tokens[current_turn][i] != -1: 
                                animating, anim_token_idx, anim_target_pos, waiting_move = True, i, tokens[current_turn][i] + dice_val, False

        if rolling and pygame.time.get_ticks() - roll_timer > 600:  
            rolling, dice_val = False, random.randint(1, 6)  
            movable = [i for i, p in enumerate(tokens[current_turn]) if (p >= 0 and p + dice_val <= 56) or (p == -1 and dice_val == 6)]  
            if not movable: next_turn()  
            else: waiting_move = True

    elif current_state == "WIN":
        screen.fill(BG)
        win_lbl = font_ui.render(f"{winner} WINS!", True, WHITE)
        screen.blit(win_lbl, (WIDTH//2 - win_lbl.get_width()//2, HEIGHT//2))
        for event in pygame.event.get():
            if event.type == pygame.MOUSEBUTTONDOWN or event.type == pygame.KEYDOWN: current_state = "MENU"

    pygame.display.update()  
    clock.tick(60)

pygame.quit()